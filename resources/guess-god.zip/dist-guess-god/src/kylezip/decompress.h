extern "C" int decompress(const char *fname);

